import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sahand Warehouse',
      home: Scaffold(
        appBar: AppBar(title: const Text('Sahand Warehouse')),
        body: const Center(child: Text('Welcome to Sahand Warehouse App')),
      ),
    );
  }
}
